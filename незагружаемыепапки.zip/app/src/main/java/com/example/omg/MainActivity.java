package com.example.omg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private MediaPlayer player1Sound,player2Sound;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new DrawView(this));

        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        player1Sound=MediaPlayer.create(this,R.raw.player1);
        player2Sound=MediaPlayer.create(this,R.raw.player2);
    }

    static class DrawView extends View{
        int a = 0;
        static Game game = new Game();
        Paint p=new Paint();
        public DrawView(Context context){
            super(context);
        }
        public void DrawPic1(Canvas canvas, int x, int y)
        {
            Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.krestik);
            canvas.drawBitmap(bitmap,x,y,p);

        }
        public void DrawPic2(Canvas canvas, int x, int y)
        {
            Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.nolik);
            canvas.drawBitmap(bitmap,x,y,p);
        }
        public boolean onTouchEvent(MotionEvent event){
            float X = event.getX();
            float Y = event.getY();
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            int w = displayMetrics.widthPixels;
            int h =displayMetrics.heightPixels;
            if(game.getRun()!=0){
                int i=0,j=0;
                if(X>=0 && X<=w/3) i=0;
                if(X>=w/3+10 && X<=2*w/3+10) i=1;
                if(X>=2*w/3+20) i=2;

                if(Y>=0 && Y<=w/3) j=0;
                if(Y>=w/3+10 && Y<=2*w/3+10) j=1;
                if(Y>=2*w/3+20) j=2;

                if(game.get(i,j)==0){
                    game.set(i,j);
                    game.change_player();
                    invalidate();}
            }

            return true;
        }



        @Override
        protected void onDraw(Canvas canvas){
            canvas.drawColor(Color.BLACK);
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            int w = displayMetrics.widthPixels;
            int h = displayMetrics.heightPixels;
            p.setColor(Color.BLUE);
            p.setStrokeWidth(10);
            canvas.drawLine(0,w/3,w, w/3,p);
            canvas.drawLine(0,2*w/3,w, 2*w/3,p);
            canvas.drawLine(w/3, 50,w/3,w,p);
            canvas.drawLine(2*w/3, 50,2*w/3,w,p);
            for(int i=0;i<3;i++)
                for(int j=0;j<3;j++)
                    if(game.get(i,j)==1) {
                        DrawPic1( canvas, 50+i*w/3, 50+j*w/3);
                    }
                    else if(game.get(i,j)==2) {
                        DrawPic2( canvas, 50+i*w/3, 50+j*w/3);

                    }
            String s = new String();
            int stat=game.check();
            if(stat==0 && game.getPlayer()==1) {
                p.setColor(Color.MAGENTA);
                s="    Ход первого игрока";
            }
            if(stat==0 && game.getPlayer()==2) {
                p.setColor(Color.YELLOW);
                s="    Ход второго игрока";
            }
            if(stat!=0 && stat!=9 && game.getPlayer()==2) {
                p.setColor(Color.GREEN);
                s="Победа первого игрока";
            }
            if(stat!=0 && stat!=9 && game.getPlayer()==1) {
                p.setColor(Color.GREEN);
                s="Победа второго игрока";
            }
            if(stat==9) {
                p.setColor(Color.GREEN);
                s="                 Ничья";
            }
            if(stat==1){
                canvas.drawLine(w/6,-3*w/6,w/6,6*w/6,p);
            }
            if(stat==2){
                canvas.drawLine(w/2, -3*w/6, w/2, 6*w/6,p);
            }
            if(stat==3){
                canvas.drawLine(21*w/25,-3*w/6,21*w/25,6*w/6,p );
            }
            if(stat==4){
                canvas.drawLine(-3*w/6,w/6,6*w/6,w/6,p);
            }
            if(stat==5){
                canvas.drawLine(-3*w/6,w/2,6*w/6,w/2,p);
            }
            if(stat==6){
                canvas.drawLine(-3*w/6,21*w/25,6*w/6,21*w/25,p);
            }
            if(stat==7){
                canvas.drawLine(-w/6,-1*w/6,25*w/25,6*w/6,p);
            }
            if(stat==8){
                canvas.drawLine(24*w/25,1*w/20,-w/30,6*w/6,p);
            }
            p.setTextSize(95);
            canvas.drawText(s,13,3*w/3+450,p);
        }

    }
    }
    class Game
    {
        private MediaPlayer player1,player2;
        private Button najatieSound;
        int [][] a = {{0,0,0},{0,0,0},{0,0,0}};
        int player=1,run=1;
        public void set(int i, int j){
            a[i][j]=player;
        }
        public void change_player(){
            if(player==1) player=2;
            else player=1;
        }
        public int get(int i, int j) {
            return a[i][j];
        }
        public int getPlayer(){return player;}
        public int check(){
            int state = 0;
            if(a[0][0]!=0&&a[0][0]==a[0][1]&&a[0][1]==a[0][2]) state=1; else
            if(a[1][0]!=0&&a[1][0]==a[1][1]&&a[1][1]==a[1][2]) state=2; else
            if(a[2][0]!=0&&a[2][0]==a[2][1]&&a[2][1]==a[2][2]) state=3; else

            if(a[0][0]!=0&&a[0][0]==a[1][0]&&a[1][0]==a[2][0]) state=4; else
            if(a[0][1]!=0&&a[0][1]==a[1][1]&&a[1][1]==a[2][1]) state=5; else
            if(a[0][2]!=0&&a[0][2]==a[1][2]&&a[1][2]==a[2][2]) state=6; else

            if(a[0][0]!=0&&a[0][0]==a[1][1]&&a[1][1]==a[2][2]) state=7; else
            if(a[0][2]!=0&&a[0][2]==a[1][1]&&a[1][1]==a[2][0]) state=8; else

                if(a[0][0]*a[0][1]*a[0][2]*a[1][0]*a[1][1]*a[1][2]*a[2][0]*a[2][1]*a[2][2]!=0)
                    state=9;
            if(state!=0) run=0;
            return state;
        }
        public int getRun(){
            return run;
        }
        public void soundPlayButton(MediaPlayer sound){
            sound.start();
        }
    }



