package com.example.omg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class Pravila extends AppCompatActivity {

    private Button nazad_button;
    private MediaPlayer nazadSound;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pravila);
        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        nazad_button=findViewById(R.id.nazad_button);
        nazadSound=MediaPlayer.create(this,R.raw.player2);
        nazad_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                soundPlayButton(nazadSound);
                nazad(v);
            }
        });
    }
    public void nazad(View v){
        Intent intent = new Intent(this, Start.class);
        startActivity(intent);
    }
    public void soundPlayButton(MediaPlayer sound){
        sound.start();
    }
}